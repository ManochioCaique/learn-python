""" 
    Escreva um programa que retorne o tamanho da lista.
    Autor: Caique Manochio 
    Data: 03/04/2024
"""

#Lista para ser usadas
numeros = [5,15,3,67,8,9,1,7,4,100,97,47,2,72]

#vendo o tamanho da lista
tamanho = len(numeros)

print(f"A lista possuio tamanho de {tamanho}")