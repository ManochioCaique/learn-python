"""Crie um programa em Python que imprima a mensagem na tela: “Hello world!”
   Autor: Caique Manochio
   Data: 01/04/2024_
"""
print("Hello World!")