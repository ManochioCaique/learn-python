"""
    Escreva um programa que:
    Autor: Caique Manochio
    Data: 01/04/2024_
"""

#a. Encontre a raiz quadrada de 25;
#from math import sqrt (usando o biblioteca math)
raiz = (25**(1/2))
print(f"A raiz quadrada de 25 é {raiz}")

#b. Imprima o resultado de 2³;
expo = (3**3)
print(f" O resultado de  2³ é {expo}")

#c. Some o quadrado de 3 com 2³;
resul = (3**2) + (2**3)
print(f"A soma de quadrado de 3 com cubo de 2 é {resul}")

#d. Imprima o resto de 7² pela raiz quadrada de 625;
resul2 = (7**2)%(625**(1/2))
print(f"O resto de 7² dividido pela raiz quadrade de 625 é {resul2}")





