"""
    Escreva um programa que:
    Autor: Caique Manochio
    Data: 01/04/2024_
"""
#a. Some os números 2 e 2;
soma = (2 + 2)
print(f"A soma de 2 com 2 é {soma}")

#b. Multiplique os números 7 e 4;
multiplica = (7 * 4)
print(f"A Multiplicação de 7 por 4 é {multiplica}")

#c. Divida o número 9 por 3; 
divisao = (9 / 3)
print(f"A divisão de 9 por 3 é {divisao}")



